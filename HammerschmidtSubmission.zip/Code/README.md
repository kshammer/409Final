##Requirements
1. matplotlib
2. numpy
3. Python 3
# Competitive Learning
* To change the amount of neurons generated change the genRandomNeurons parameter
* To change amount of iterations change the calcNet parameter
* To use predefined Neurons change the code in genNeurons
# Bayes Analysis 
* Run as normal 